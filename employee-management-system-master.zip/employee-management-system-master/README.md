# Employee Database Management System

## This project was developed to help business owners manager their employees more efficiently and easily.

Using this system, anyone can add, delete, update, view or delete employees from the system using a Graphical User Interface.

The system uses Swing GUI components for the interface and JDBC to connect the system to the database.

The processing happens in real-time so it's very convenient for the owner/user to see the changes immediately.

**Language:** Java

**IDE:** Eclipse

